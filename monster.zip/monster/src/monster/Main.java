package monster;


import java.util.ArrayList;

import monster.character.Monster;
import monster.character.Player;
import monster.item.HpPotion;
import monster.item.MpPotion;
import monster.map.battleMap;
import monster.map.hunting_ground;

public class Main {

	public static void main(String[] args) {
	
		
		
		
		new MainFrame();
		
		
	}

}
